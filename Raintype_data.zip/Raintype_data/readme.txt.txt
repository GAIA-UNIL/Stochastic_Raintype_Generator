2001 - 2017 time series of observed rain types and associated meteorological covariates over central Germany.
This dataset id fully described in the section 2 of: Benoit L., Vrac M., Mariethoz G. Accounting for rain type non-stationarity in sub-daily stochastic weather generators.
M_datevec.mat contains date and time information. C1: year, C2: month, C3: day, C4: hour, C5:minute, C6:second.
V_raintypes_6clusters.mat contains the rain type time series.
M_Cov_ERA5.mat contains the meteorological covariates derived from ERA5 reanalysis. C1: Sea level pressure, C2: mean daily temperature, C3: Humidity, C4: sub-daily temperature variations, C5: wind 850hPa Eastward, C6: wind 850hPa Northward 
